﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Drogueria.Models
{
    public partial class Producto
    {
        public Producto()
        {
            Pedidos = new HashSet<Pedido>();
        }

        public decimal Id { get; set; }
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public decimal? UnidadesDisponibles { get; set; }
        public decimal? NumeroProductos { get; set; }
        public decimal? Precio { get; set; }

        public virtual ICollection<Pedido> Pedidos { get; set; }
    }
}
