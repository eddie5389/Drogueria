﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Drogueria.Models
{
    public partial class Pedido
    {
        public decimal Id { get; set; }
        public decimal? IdCliente { get; set; }
        public decimal? IdProducto { get; set; }
        public decimal? CantidadProducto { get; set; }
        public DateTime? Fecha { get; set; }
        public decimal? Total { get; set; }

        public virtual Producto IdProductoNavigation { get; set; }
    }
}
