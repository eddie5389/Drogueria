﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace Drogueria.Models
{
    public partial class DrogueriaContext : DbContext
    {
        public DrogueriaContext()
        {
        }

        public DrogueriaContext(DbContextOptions<DrogueriaContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Pedido> Pedidos { get; set; }
        public virtual DbSet<Producto> Productos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
  //              optionsBuilder.UseSqlServer("server=LAPTOP-KGGSOL1K; database=Drogueria; integrated security=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Modern_Spanish_CI_AS");

            modelBuilder.Entity<Pedido>(entity =>
            {
                entity.ToTable("Pedido");

                entity.Property(e => e.Id)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.CantidadProducto)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("Cantidad_Producto");

                entity.Property(e => e.Fecha).HasColumnType("datetime");

                entity.Property(e => e.IdCliente)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("Id_Cliente");

                entity.Property(e => e.IdProducto)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("Id_Producto");

                entity.Property(e => e.Total).HasColumnType("money");

                entity.HasOne(d => d.IdProductoNavigation)
                    .WithMany(p => p.Pedidos)
                    .HasForeignKey(d => d.IdProducto)
                    .HasConstraintName("FK_Pedido_Producto");
            });

            modelBuilder.Entity<Producto>(entity =>
            {
                entity.ToTable("Producto");

                entity.Property(e => e.Id)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Nombre).HasMaxLength(50);

                entity.Property(e => e.NumeroProductos)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("Numero_Productos");

                entity.Property(e => e.Precio).HasColumnType("money");

                entity.Property(e => e.Tipo).HasMaxLength(50);

                entity.Property(e => e.UnidadesDisponibles)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("Unidades_Disponibles");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
